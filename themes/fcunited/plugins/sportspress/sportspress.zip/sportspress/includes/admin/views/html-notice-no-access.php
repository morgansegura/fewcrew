<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div id="message" class="error">
	<p><?php esc_attr_e( 'You are not allowed to edit this item.', 'sportspress' ); ?></p>
</div>
